import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from config.config import config
from SparkEggfile.preprocess import preprocessor
from sklearn.preprocessing import LabelEncoder

class train_test:

    def __init__(self):
        self.con = config()
        self.obj = preprocessor(self.con.context)
        self.spark = self.con.spark

    def train_test(self):


        params = {
            'task': 'train',
            'boosting_type': 'gbdt',
            'objective': 'regression',
            'metric': {'l2', 'auc', 'regression'},
            'is_training_metric': True,
            'metric_freq': 5,
            'num_leaves': 31,
            'learning_rate': 0.5,
            'feature_fraction': 0.9,
            'bagging_fraction': 0.8,
            'bagging_freq': 5,
            'verbose': 1,
            'device': 'cpu'
        }
        self.spark.sql("REFRESH TABLE business_users_test.tmp_single_modem_training_set")

        data = self.obj.get_data("business_users_test.tmp_single_modem_training_set", ["gateway_macaddress",
                                                                              "intermittancy_perc",
                                                                              "scaled_accessibility_perc_full_day",
                                                                              "ticket_count",
                                                                              "percent_outlier_far_between_0_to_20",
                                                                              "percent_outlier_far_between_20_to_40",
                                                                              "percent_outlier_far_between_40_to_60",
                                                                              "percent_outlier_far_between_60_to_80",
                                                                              "percent_outlier_far_between_80_to_100",
                                                                              "percent_outlier_near_between_0_to_20",
                                                                              "percent_outlier_near_between_20_to_40",
                                                                              "percent_outlier_near_between_40_to_60",
                                                                              "percent_outlier_near_between_60_to_80",
                                                                              "percent_outlier_near_between_80_to_100",
                                                                              "percent_80dbm_near_between_0_to_20",
                                                                              "percent_80dbm_near_between_20_to_40",
                                                                              "percent_80dbm_near_between_40_to_60",
                                                                              "percent_80dbm_near_between_60_to_80",
                                                                              "percent_80dbm_near_between_80_to_100",
                                                                              "percent_80dbm_far_between_0_to_20",
                                                                              "percent_80dbm_far_between_20_to_40",
                                                                              "percent_80dbm_far_between_40_to_60",
                                                                              "percent_80dbm_far_between_60_to_80",
                                                                              "percent_80dbm_far_between_80_to_100",
                                                                              "ticket_moving_average_between_80_to_100",
                                                                              "ticket_moving_average_between_60_to_80",
                                                                              "ticket_moving_average_between_40_to_60",
                                                                              "ticket_moving_average_between_20_to_40",
                                                                              "ticket_moving_average_between_0_to_20",
                                                                              "label"]).toPandas()

        encoder = LabelEncoder()
        encoder.fit(data["gateway_macaddress"].values)
        encoded_GW = encoder.transform(data["gateway_macaddress"])
        data["encoded_GW"] = encoded_GW
        y = data[["label"]]
        X = data[["encoded_GW",
                  "intermittancy_perc",
                  "scaled_accessibility_perc_full_day",
                  "ticket_count",
                  "percent_outlier_far_between_0_to_20",
                  "percent_outlier_far_between_20_to_40",
                  "percent_outlier_far_between_40_to_60",
                  "percent_outlier_far_between_60_to_80",
                  "percent_outlier_far_between_80_to_100",
                  "percent_outlier_near_between_0_to_20",
                  "percent_outlier_near_between_20_to_40",
                  "percent_outlier_near_between_40_to_60",
                  "percent_outlier_near_between_60_to_80",
                  "percent_outlier_near_between_80_to_100",
                  "percent_80dbm_near_between_0_to_20",
                  "percent_80dbm_near_between_20_to_40",
                  "percent_80dbm_near_between_40_to_60",
                  "percent_80dbm_near_between_60_to_80",
                  "percent_80dbm_near_between_80_to_100",
                  "percent_80dbm_far_between_0_to_20",
                  "percent_80dbm_far_between_20_to_40",
                  "percent_80dbm_far_between_40_to_60",
                  "percent_80dbm_far_between_60_to_80",
                  "percent_80dbm_far_between_80_to_100",
                  "ticket_moving_average_between_80_to_100",
                  "ticket_moving_average_between_60_to_80",
                  "ticket_moving_average_between_40_to_60",
                  "ticket_moving_average_between_20_to_40",
                  "ticket_moving_average_between_0_to_20"
                  ]]

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=7)
        train_data = lgb.Dataset(X_train, label=y_train, free_raw_data=False)
        gbm = lgb.train(
            params,
            train_data,
            num_boost_round=100)
        print('begin to predict data')
        y_pred = gbm.predict(X_test)
        regression = y_pred
        predictions = [round(value) for value in y_pred]

        accuracy = accuracy_score(y_test, predictions)
        print("Accuracy: %.2f%%" % (accuracy * 100.0))
        cm = confusion_matrix(y_test, predictions)

        # print('Plotting feature importances...')
        # ax = lgb.plot_importance(gbm, max_num_features=23)
        # display()
        for f in range(len(gbm.feature_importance())):

            val = list(gbm.feature_importance())[f]

            if val != 0:
                print("rank:", val, list(gbm.feature_name())[list(gbm.feature_importance()).index(val)])
        print(cm)
        # fig, ax = plt.subplots()
        # ax = lgb.plot_importance(gbm, max_num_features=40, figsize=(15,15))
        # ax.plot(lgb.plot_importance(gbm, max_num_features=40, figsize=(15,15)))
        # display(fig)

        # fig, ax = plt.subplots()
        # ax.plot(x, y, 'k--')
        # ax.plot(x, y2, 'ro')

        # # set ticks and tick labels
        # ax.set_xlim((0, 2*np.pi))
        # ax.set_xticks([0, np.pi, 2*np.pi])
        # ax.set_xticklabels(['0', '$\pi$','2$\pi$'])
        # ax.set_ylim((-1.5, 1.5))
        # ax.set_yticks([-1, 0, 1])

        # # Only draw spine between the y-ticks
        # ax.spines['left'].set_bounds(-1, 1)
        # # Hide the right and top spines
        # ax.spines['right'].set_visible(False)
        # ax.spines['top'].set_visible(False)
        # # Only show ticks on the left and bottom spines
        # ax.yaxis.set_ticks_position('left')
        # ax.xaxis.set_ticks_position('bottom')

        self.spark.sql("REFRESH TABLE business_users_test.tmp_single_modem_prediction_moving_average")

        data = self.obj.get_data("business_users_test.tmp_single_modem_prediction_moving_average", ["gateway_macaddress",
                                                                                       "polling_date",
                                                                                       "intermittancy_perc",
                                                                                       "scaled_accessibility_perc_full_day",
                                                                                       "ticket_count",
                                                                                       "percent_outlier_far_between_0_to_20",
                                                                                       "percent_outlier_far_between_20_to_40",
                                                                                       "percent_outlier_far_between_40_to_60",
                                                                                       "percent_outlier_far_between_60_to_80",
                                                                                       "percent_outlier_far_between_80_to_100",
                                                                                       "percent_outlier_near_between_0_to_20",
                                                                                       "percent_outlier_near_between_20_to_40",
                                                                                       "percent_outlier_near_between_40_to_60",
                                                                                       "percent_outlier_near_between_60_to_80",
                                                                                       "percent_outlier_near_between_80_to_100",
                                                                                       "percent_80dbm_near_between_0_to_20",
                                                                                       "percent_80dbm_near_between_20_to_40",
                                                                                       "percent_80dbm_near_between_40_to_60",
                                                                                       "percent_80dbm_near_between_60_to_80",
                                                                                       "percent_80dbm_near_between_80_to_100",
                                                                                       "percent_80dbm_far_between_0_to_20",
                                                                                       "percent_80dbm_far_between_20_to_40",
                                                                                       "percent_80dbm_far_between_40_to_60",
                                                                                       "percent_80dbm_far_between_60_to_80",
                                                                                       "percent_80dbm_far_between_80_to_100",
                                                                                       "ticket_moving_average_between_80_to_100",
                                                                                       "ticket_moving_average_between_60_to_80",
                                                                                       "ticket_moving_average_between_40_to_60",
                                                                                       "ticket_moving_average_between_20_to_40",
                                                                                       "ticket_moving_average_between_0_to_20"]).toPandas()

        encoder = LabelEncoder()
        encoder.fit(data["gateway_macaddress"].values)
        data["encoded_GW"] = encoder.transform(data["gateway_macaddress"])

        # filename='dbfs:/tmp/zeeshan1/pods_classifier.sav'
        # model = pickle.load(open(filename, 'rb'))
        X = data[["encoded_GW",
              "intermittancy_perc",
              "scaled_accessibility_perc_full_day",
              "ticket_count",
              "percent_outlier_far_between_0_to_20",
              "percent_outlier_far_between_20_to_40",
              "percent_outlier_far_between_40_to_60",
              "percent_outlier_far_between_60_to_80",
              "percent_outlier_far_between_80_to_100",
              "percent_outlier_near_between_0_to_20",
              "percent_outlier_near_between_20_to_40",
              "percent_outlier_near_between_40_to_60",
              "percent_outlier_near_between_60_to_80",
              "percent_outlier_near_between_80_to_100",
              "percent_80dbm_near_between_0_to_20",
              "percent_80dbm_near_between_20_to_40",
              "percent_80dbm_near_between_40_to_60",
              "percent_80dbm_near_between_60_to_80",
              "percent_80dbm_near_between_80_to_100",
              "percent_80dbm_far_between_0_to_20",
              "percent_80dbm_far_between_20_to_40",
              "percent_80dbm_far_between_40_to_60",
              "percent_80dbm_far_between_60_to_80",
              "percent_80dbm_far_between_80_to_100",
              "ticket_moving_average_between_80_to_100",
              "ticket_moving_average_between_60_to_80",
              "ticket_moving_average_between_40_to_60",
              "ticket_moving_average_between_20_to_40",
              "ticket_moving_average_between_0_to_20"
              ]]

        data['household_score'] = gbm.predict(X)
        data['pods_recommendation'] = [round(value) for value in data['household_score']]
        data = data[["gateway_macaddress",
                 "intermittancy_perc",
                 "scaled_accessibility_perc_full_day",
                 "ticket_count",
                 "percent_outlier_far_between_0_to_20",
                 "percent_outlier_far_between_20_to_40",
                 "percent_outlier_far_between_40_to_60",
                 "percent_outlier_far_between_60_to_80",
                 "percent_outlier_far_between_80_to_100",
                 "percent_outlier_near_between_0_to_20",
                 "percent_outlier_near_between_20_to_40",
                 "percent_outlier_near_between_40_to_60",
                 "percent_outlier_near_between_60_to_80",
                 "percent_outlier_near_between_80_to_100",
                 "percent_80dbm_near_between_0_to_20",
                 "percent_80dbm_near_between_20_to_40",
                 "percent_80dbm_near_between_40_to_60",
                 "percent_80dbm_near_between_60_to_80",
                 "percent_80dbm_near_between_80_to_100",
                 "percent_80dbm_far_between_0_to_20",
                 "percent_80dbm_far_between_20_to_40",
                 "percent_80dbm_far_between_40_to_60",
                 "percent_80dbm_far_between_60_to_80",
                 "percent_80dbm_far_between_80_to_100",
                 "ticket_moving_average_between_80_to_100",
                 "ticket_moving_average_between_60_to_80",
                 "ticket_moving_average_between_40_to_60",
                 "ticket_moving_average_between_20_to_40",
                 "ticket_moving_average_between_0_to_20",
                 "household_score",
                 "pods_recommendation"]]

        output = self.spark.createDataFrame(data)
        self.spark.sql("DROP TABLE IF EXISTS business_users_test.tmp_single_modem_prediction_classifier")

        output.write.saveAsTable("business_users_test.tmp_single_modem_prediction_classifier")

        self.spark.sql("REFRESH TABLE business_users_test.tmp_single_modem_prediction_classifier")

        predictions = self.spark.get_data("business_users_test.tmp_single_modem_prediction_classifier", ["gateway_macaddress",
                                                                                              "pods_recommendation"])

        self.spark.sql("REFRESH TABLE business_users_test.tmp_single_modem_recommendation")

        recommendations = self.obj.get_data("business_users_test.tmp_single_modem_recommendation", "ALL")

        pred_recommendation = self.obj.join_two_frames(recommendations, predictions, "inner", "gateway_macaddress")

        self.spark.sql("DROP TABLE IF EXISTS business_users_test.tmp_single_modem_recommendation_predictions")

        pred_recommendation.write.saveAsTable("business_users_test.tmp_single_modem_recommendation_predictions")

        df = self.obj.get_data("business_users_test.tmp_single_modem_recommendation_predictions", "ALL")

        self.spark.sql("DROP TABLE IF EXISTS business_users_test.tmp_single_modem_recommendation")

        df.write.saveAsTable("business_users_test.tmp_single_modem_recommendation")



