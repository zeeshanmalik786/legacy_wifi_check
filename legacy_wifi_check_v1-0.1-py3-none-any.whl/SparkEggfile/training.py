import xgboost as xgb
from SparkEggfile.preprocess import preprocessor
from config.config import config
from pyspark.sql import functions as func
from pyspark.sql.functions import rank, col, concat
from pyspark.sql.functions import countDistinct
import pyspark.sql.functions as f
from pyspark.sql.functions import lit
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import pickle
import os
class training:

    def __init__(self):

        self.con = config()
        self.obj = preprocessor(self.con.context)
        self.spark = self.con.spark

    def training(self):

        data = self.obj.get_data("business_users_test.tmp_single_modem_training_set", ["gateway_macaddress",
                                                                                       "intermittancy_perc",
                                                                                       "scaled_accessibility_perc_full_day",
                                                                                       "ticket_count",
                                                                                       "percent_outlier_far_between_0_to_79",
                                                                                       "percent_outlier_far_between_80_to_100",
                                                                                       "percent_outlier_near_between_0_to_79",
                                                                                       "percent_outlier_near_between_80_to_100",
                                                                                       "percent_80dbm_near_between_0_to_79",
                                                                                       "percent_80dbm_near_between_80_to_100",
                                                                                       "percent_80dbm_far_between_0_to_79",
                                                                                       "percent_80dbm_far_between_80_to_100",
                                                                                       "label"]).toPandas()

        encoder = LabelEncoder()
        encoder.fit(data["gateway_macaddress"].values)

        encoded_GW = encoder.transform(data["gateway_macaddress"])

        data["encoded_GW"] = encoded_GW

        y = data[["label"]]

        X = data[["encoded_GW",
              "intermittancy_perc",
              "scaled_accessibility_perc_full_day",
              "ticket_count",
              "percent_outlier_far_between_0_to_79",
              "percent_outlier_far_between_80_to_100",
              "percent_outlier_near_between_0_to_79",
              "percent_outlier_near_between_80_to_100",
              "percent_80dbm_near_between_0_to_79",
              "percent_80dbm_near_between_80_to_100",
              "percent_80dbm_far_between_0_to_79",
              "percent_80dbm_far_between_80_to_100"
              ]]

        params = {}
        params['learning_rate'] = 0.003
        params['n_estimators'] = 1000
        params['max_depth'] = 5
        params['min_child_weight'] = 1
        params['gamma'] = 0
        params['subsample'] = 0.8
        params['colsample_bytree'] = 0.8
        params['objective'] = 'binary:logistic'
        params['nthread'] = 4
        params['scale_pos_weight'] = 1
        params['seed'] = 27

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=7)
        dtrain = xgb.DMatrix(X_train, label=y_train.values.ravel())
        dtest = xgb.DMatrix(X_test)
        bst = xgb.train(params, dtrain, num_boost_round=10)
        # model = xgb.XGBClassifier().fit(X_train, y_train.values.ravel())

        filename = 'pods_classifier.model'
        bst.save_model(filename)
        # pickle.dump(model, open(filename, 'wb'))
        y_pred = bst.predict(dtest)
        predictions = [round(value) for value in y_pred]
        accuracy = accuracy_score(y_test, predictions)
        print("Accuracy: %.2f%%" % (accuracy * 100.0))

